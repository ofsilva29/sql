﻿using Bergs.AvaliacaoCSharp.Data.Util;
using System.Collections.Generic;

namespace Bergs.AvaliacaoCSharp.Data
{
    public interface IRepository<T>
    {        
        Retorno Save(List<T> item);
    }
}
