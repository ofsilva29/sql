﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bergs.AvaliacaoCSharp.Domain
{
    public class ConvenioFavorita
    {
        public ConvenioFavorita()
        {
            ValorTotal = 0;
            Quantidade = 0;
        }

        public string cnpj { get; set; }
        public string Chave { get; set; }
        public int qtEmpre { get; set; }
        public int Quantidade { get; set; }
        public TiposConvenios TipoConvenios { get; set; }
    }
}
