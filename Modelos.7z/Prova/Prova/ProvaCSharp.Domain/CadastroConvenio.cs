﻿using Bergs.AvaliacaoCSharp.Data;
using Bergs.AvaliacaoCSharp.Data.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bergs.AvaliacaoCSharp.Domain
{
    public class CadastroConvenio
    {
        public List<Convenio> ListaConvenio { get; set; }

             
        #region Adicionar Convenio
        public Retorno AdicionarConvenio(String strCNPJ, String strrazaoSocial, String qtEmpre, )
        {
            Convenio convenio = new Convenio();
            try
            {
                convenio.TipoConvenio = (TiposConvenio)Convert.ToInt16(strRazaoSocial);
            }
            catch (Exception e)
            {
                String msg = String.Format("30 - Falha ao converter Tipo Chave: {0}", e.Message);
                return new Retorno(false, 30, msg);
            }

            Retorno ret = validarChave(convenio.TipoConvenio, TipoConvenio);
            if (!ret.Sucesso)
            {
                return ret;
            }

            ret = verificaChaveExistente(strConvenio);
            if (!ret.Sucesso)
            {
                return ret;
            }

            convenio.Convenio = strConvenio;
            convenio.cnpj = strCNPJ;

            ListaConvenio.Add(convenio);
            return new Retorno(true, 0, "Sucesso.");
        }

        private Retorno verificaConvenioExistente(String strChave)
        {
            foreach (Convenio ch in ListaConvenio)
            {
                if (ch.Convenio.Equals(strConvenio))
                {
                    return new Retorno(false, 65, "65 - Convenio duplicada.");
                }
            }
            return new Retorno(true, 0, "Sucesso.");
        }

        private Retorno validarConvenio(TiposConvenio tipo, String strConvenio)
        {
            switch (tipo)
            {
                case TiposConvenio.Cadastro:
                    return validarCadastro(strConvenio);
                case TiposConvenio.Deferido:
                    return validarDeferido(strConvenio);
                case TiposConvenio.Susoenso:
                    return validarSuspenso(strConvenio);
                default:
                    return new Retorno(false, 30, "30 - Tipo Chave inválido!");
            }
        }

        private Retorno validarCadastro(string convenio)
        {
            String regex = "^\\d{11}$";
            if (System.Text.RegularExpressions.Regex.IsMatch(convenio, regex))
            {
                return new Retorno(true, 0, "Sucesso.");
            }
            else
            {
                return new Retorno(false, 40, "40 - CPF inválido.");
            }
        }

        private Retorno validarDeferido(String convenio)
        {
            String regex = "^\\+[1-9][0-9]\\d{11}$";
            if (System.Text.RegularExpressions.Regex.IsMatch(convenio, regex))
            {
                return new Retorno(true, 0, "Sucesso.");
            }
            else
            {
                return new Retorno(false, 50, "50 - Telefone inválido! Formato esperado: +5551999999999."); ;
            }
        }

        private Retorno validarSusoenso(String convenio)
        {
            String regex = "^\\+[1-9][0-9]\\d{11}$";
            if (System.Text.RegularExpressions.Regex.IsMatch(convenio, regex))
            {
                return new Retorno(true, 0, "Sucesso.");
            }
            else
            {
                return new Retorno(false, 50, "50 - Telefone inválido! Formato esperado: +5551999999999."); ;
            }
        }
        #endregion

        #region Remover Convenio
        public Retorno EnviarPIX(String strChave, String strValor)
        {
            Decimal valor = 0;
            Retorno retValidaValor = TryGetValor(strValor, out valor);
            if (!retValidaValor.Sucesso)
            {
                return retValidaValor;
            }

            ChaveFavorita convenio = getChave(strChave);
            if (chave == null)
            {
                return new Retorno(false, 60, "60 - Chave informada não existe.");
            }

            Retorno retSaldo = ValidarSaldo(valor);
            if (!retSaldo.Sucesso)
            {
                return retSaldo;
            }
            convenio.ValorTotal = convenio.ValorTotal + valor;
            convenio.Quantidade = convenio.Quantidade + 1;
            Saldo = Saldo - valor;
            return new Retorno(true, 0, "Sucesso.");
        }

        private ChaveFavorita getChave(String strChave)
        {
            var convenio = ListaChaves.FirstOrDefault(x => x.Chave.Equals(strChave));
            if (convenio != null)
            {
                return convenio;
            }

            return null;
        }

        private Retorno ValidarSaldo(Decimal valor)
        {
            if (Saldo >= valor)
            {
                return new Retorno(true, 0, "Sucesso.");
            }
            else
            {
                return new Retorno(false, 70, "70 - Saldo insuficiente.");
            }
        }
        #endregion

        #region Listar Convenio
        public RetornoListaChave<List<ChaveFavorita>> ListarChavesFavoritas()
        {
            var ret = new RetornoListaChave<List<ChaveFavorita>>(true, 0, "Sucesso.");
            ListaChaves.OrderBy(x=> x.ValorTotal);
            ret.Result = ListaChaves;
            return ret;
        }
        #endregion

        #region Salvar Convenio
        public Retorno Persistir()
        {
            var repo = new ChaveFavoritaRepository();

            return repo.Save(ListaChaves.Select(chave => new ChaveFavoritaDTO()
            {
                Chave = convenio.Chave,
                TipoChave = (int)convenio.TipoChave,
                NomeTitular = convenio.NomeTitular,
                Quantidade = convenio.Quantidade,
                ValorTotal = convenio.ValorTotal
            }).ToList());            
        }

        #endregion

        private Retorno TryGetValor(string str, out decimal vlr)
        {
            vlr = 0;
            if (Decimal.TryParse(str, out vlr))
            {
                if (vlr <= 0)
                {
                    return new Retorno(false, 20, "20 - Valor deve ser maior ou igual a zero.");
                }
            }
            else
            {
                return new Retorno(false, 10, "Valor inválido.");
            }
            Retorno ret = new Retorno(true, 0, "");
            return ret;
        }
    }
}
