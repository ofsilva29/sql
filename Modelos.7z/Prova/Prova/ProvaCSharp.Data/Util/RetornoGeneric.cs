﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bergs.AvaliacaoCSharp.Data.Util
{
    public class RetornoConvenio<T> : Retorno
    {
        public RetornoConvenio(bool sucesso, int codRetorno, string mensagem) : base(sucesso, codRetorno, mensagem)
        {            
        }

        public T Result { get; set; }        
    }
}
