﻿using Bergs.ProvacSharp.BD;
using Bergs.AvaliacaoCSharp.Data.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Bergs.AvaliacaoCSharp.Data
{
    public class ConvenioRepository : IRepository<ConvenioDTO>
    {
        private readonly string pathDB;
        public ConvenioRepository()
        {
            pathDB = "C:\\soft\\pxc\\data\\Pxcz02da.mdb";
        }

        public Retorno Save(List<ConvenioDTO> qtEmpregados)
        {
            using (var db = new AcessoBancoDados(pathDB))
            {
                db.Abrir();
                try
                {
                    if (!db.ExecutarDelete("DELETE FROM CONVENIO"))
                    {
                        return new Retorno(false, 980, "Falha ao deletar registros.");
                    }

                    foreach (var qtEmpre in qtEmpregados)
                    {
                        if (!db.ExecutarInsert(GetInsertSql(qtEmpre)))
                        {
                            return new Retorno(false, 990, "Falha ao incluir registro.");
                        }
                    }                  

                    db.EfetivarComandos();
                }
                catch (Exception ex)
                {
                    return new Retorno(false, 990, "Erro ao persistir chaves: " + ex.Message);
                }
                finally
                {
                    db.Dispose();
                }
                return new Retorno(true, 0, "Com sucesso.");
            }
        }

        private string GetInsertSql(ConvenioDTO qtEmpregados)
        {
            string sql = "INSERT INTO CONVENIO (TIPO_CONVENIO, CNPJ, QTDE_PIX, VLR_TOTAL_PIX, CHAVE) VALUES(@TipoConvenio, @CNPJ, @QtdePix, @VlrTotalPix, @Chave)";

            SqlCommand command = new SqlCommand(sql);
            command.CommandType = CommandType.Text;

            command.AdicionaParametroValor("@TipoConvenio", DbType.Int32, convenio.TipoConvenio);
            command.AdicionaParametroValor("@CNPJ", DbType.String, convenio.CNPJ);

            command.AdicionaParametroValor("@QtdePix", DbType.Int32, convenio.Quantidade);
            command.AdicionaParametroValor("@VlrTotalPix", DbType.Currency, convenio.TotalPix);
            command.AdicionaParametroValor("@Chave", DbType.String, convenio.Convenio);
            
            return command.GetGeneratedQuery();            
        }
    }
}
