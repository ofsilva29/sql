﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace teste
{
    public class CadastroConvenio
    {
        private List<Convenio> convenios = new List<Convenio>();

        public Retorno CadastrarConvenio(string cnpj, string razaoSocial, int quantidadeEmpregados, StatusConvenio status, DateTime dataAtualizacao)
        {
            // Validações
            if (!System.Text.RegularExpressions.Regex.IsMatch(cnpj, @"^[1-9]\d{2,14}$"))
                return new Retorno { Codigo = 10, Mensagem = "O CNPJ informado é inválido." };

            if (convenios.Any(c => c.CNPJ == cnpj))
                return new Retorno { Codigo = 11, Mensagem = "Já existe um convênio com esse CNPJ." };

            if (razaoSocial.Length < 3)
                return new Retorno { Codigo = 12, Mensagem = "A razão social deve ter pelo menos 3 caracteres." };

            if (quantidadeEmpregados <= 0)
                return new Retorno { Codigo = 14, Mensagem = "A quantidade de empregados deve ser maior que 0." };

            // Cria e adiciona o convênio
            var convenio = new Convenio
            {
                CNPJ = cnpj,
                RazaoSocial = razaoSocial,
                QtdEmpregados = quantidadeEmpregados,
                Status = status,
                DtAtuStatus = dataAtualizacao
            };

            convenios.Add(convenio);
            return new Retorno { Codigo = 0, Mensagem = "Operação realizada com sucesso." };
        }

        public Retorno RemoverConvenio(string cnpj)
        {
            var convenio = convenios.FirstOrDefault(c => c.CNPJ == cnpj);
            if (convenio == null)
                return new Retorno { Codigo = 21, Mensagem = "Não foi encontrado nenhum convênio com o CNPJ informado." };

            convenios.Remove(convenio);
            return new Retorno { Codigo = 0, Mensagem = "Operação realizada com sucesso." };
        }

        public Retorno ListarConvenios()
        {
            if (!convenios.Any())
                return new Retorno { Codigo = 30, Mensagem = "Nenhum registro encontrado." };

            return new Retorno { Codigo = 0, Mensagem = "Convênios listados com sucesso.", Dados = convenios };
        }

        public Retorno SalvarConvênios()
        {
            using (var acessoBanco = new AcessoBancoDados("c:\\soft\\pxc\\data\\Pxcz02da.mdb")) // Altere para o caminho do seu banco
            {
                acessoBanco.Abrir();

                foreach (var convenio in convenios)
                {
                    string comandoSQL = $"INSERT INTO Convenios (CNPJ, RazaoSocial, QtdEmpregados, Status, DtAtuStatus) VALUES ('{convenio.CNPJ}', '{convenio.RazaoSocial}', {convenio.QtdEmpregados}, {(int)convenio.Status}, #{convenio.DtAtuStatus:MM/dd/yyyy}#)";
                    if (!acessoBanco.ExecutarInsert(comandoSQL))
                    {
                        return new Retorno { Codigo = 41, Mensagem = "Erro ao salvar os dados no banco." };
                    }
                }
            }

            return new Retorno { Codigo = 0, Mensagem = "Convênios salvos com sucesso." };
        }

        public int TotalConvenios()
        {
            return convenios.Count;
        }
    }
}

