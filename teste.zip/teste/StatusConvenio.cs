﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace teste
{    public enum StatusConvenio
    {
        Cadastro = 1,
        Deferido = 2,
        Suspenso = 3
    }
}
