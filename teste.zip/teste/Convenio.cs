﻿using System;

namespace teste
{
    public class Convenio
    {
        public string CNPJ { get; set; }
        public string RazaoSocial { get; set; }
        public int QtdEmpregados { get; set; }
        public StatusConvenio Status { get; set; }
        public DateTime DtAtuStatus { get; set; }
    }
}
