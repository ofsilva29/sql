﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bergs.AvaliacaoCSharp.Domain
{
    public enum SatusConvenio
    {
        Cadastro = 1,
        Deferido = 2,
        Suspenso = 3
    }
}
