﻿using Bergs.AvaliacaoCSharp.Data.Util;
using Bergs.AvaliacaoCSharp.Domain;
using System;

namespace Bergs.AvaliacaoCSharp
{
    class Program
    {
        private static CadastroConvenio cadastroConvenio = new CadastroConvenio();

        static void Main(string[] args)
        {
            montarMenu();
        }

        static void montarMenu()
        {
            Int16 opt = 0;
            while (opt != 6)
            {
                Console.Clear();
                Console.WriteLine($"== Cadastro de convênios para crédito consignado ==");
                Console.WriteLine("");
                Console.WriteLine("1.Adicionar convênio");
                Console.WriteLine("2.Remover convênio");
                Console.WriteLine("3.Listar convênio");
                Console.WriteLine("4.Salvar convênio");
                Console.WriteLine("5.Sair");
                Console.WriteLine("");
                Console.Write("Informe a opção desejada: ");
                String key = Console.ReadLine().Trim();
                Console.WriteLine("");

                try
                {
                    opt = Convert.ToInt16(key);
                }
                catch (Exception e)
                {
                    opt = 0;
                }

                if (opt >= 1 && opt <= 4)
                {
                    executarOpcao(opt);
                }
                else if (opt != 5)
                {
                    Console.WriteLine("Opção Inválida!");
                    fimAcao();
                }
            }
        }

        static void executarOpcao(Int16 opt)
        {
            switch (opt)
            {
                case 1:
                    adicionarConvenio();
                    break;
                case 2:
                    removerConvenio();
                    break;
                case 3:
                    listarConvenio();
                    break;
                case 4:
                    salvarConvenio();
                    break;
            }
        }
        
        private static void adicionarConvenio()
        {
            Console.WriteLine("");

            Console.Write("Informe o CNPJ da empresa conveniada: ");
            string cnpj = Console.ReadLine().Trim();

            Console.WriteLine("Informe a Razão Social da empresa conveniada:");
            string razaoSocial = Console.ReadLine().Trim();

            Console.Write("Informe a quaatidade de empregados: ");
            string qtEmpregados = Console.ReadLine().Trim();

            Console.Write("Digite o Status (1- Cadastro, 2- Deferido, 3- Suspenso): ");
            string status = Console.ReadLine().Trim();

            Retorno ret = cadastroConvenio.AdicionarConvenio(cnpj, razaoSocial, qtEmpregados, status);
            Console.WriteLine(ret.Mensagem);
            fimAcao();
        }

        private static void removerConvenio()
        {
            var ret = cadastroConvenio.RemoverConvenio();
            if (ret.Sucesso)
            {
                Console.WriteLine("<< LISTA DE CONVENIOS >>");
                foreach (var ch in ret.Result)
                {
                    Console.WriteLine($"{ch.Chave} - {ch.cnpj} - {ch.Quantidade} - {string.Format("{0:C}", ch.ValorTotal)}");
                }
            }
            else
            {
                Console.WriteLine(ret.Mensagem);
            }
            fimAcao();
        }

        private static void listarConvenio()
        {
            Console.WriteLine("");

            Console.Write("Informe o CNPJ da empresa conveniada: ");
            string cnpj = Console.ReadLine().Trim();

            Console.WriteLine("Informe a Razão Social da empresa conveniada:");
            string razaoSocial = Console.ReadLine().Trim();

            Console.Write("Informe a quaatidade de empregados: ");
            string qtEmpregados = Console.ReadLine().Trim();

            Console.Write("Digite o Status (1- Cadastro, 2- Deferido, 3- Suspenso): ");
            string status = Console.ReadLine().Trim();

            Retorno ret = cadastroConvenio.AdicionarConvenio(cnpj, razaoSocial, qtEmpregados, status);
            Console.WriteLine(ret.Mensagem);
            fimAcao();
        }

        private static void salvarConvenio()
        {
            Retorno ret = cadastroConvenio.Persistir();
            if (ret.Sucesso)
            {
                Console.WriteLine("Sucesso!");
            }
            else
            {
                Console.WriteLine(ret.Mensagem);
            }
            fimAcao();
        }

        private static void fimAcao()
        {
            Console.WriteLine("");
            Console.WriteLine("<<Pressione Enter>>");
            Console.ReadKey();
        }
    }
}