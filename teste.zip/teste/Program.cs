﻿using System;
using System.Collections.Generic;

namespace teste
{
    public class Program
    {
        private static CadastroConvenio cadastro = new CadastroConvenio();

        public static void Main(string[] args)
        {
            int opcao;

            do
            {
                // Menu principal
                Console.Clear();
                Console.WriteLine("Cadastro de convênios para crédito consignado");
                Console.WriteLine("---------------------------------------------");
                Console.WriteLine($"Total de convênios: {cadastro.TotalConvenios()}");
                Console.WriteLine("1. Adicionar convênio");
                Console.WriteLine("2. Remover convênio");
                Console.WriteLine("3. Listar convênios");
                Console.WriteLine("4. Salvar convênios");
                Console.WriteLine("5. Sair");
                Console.Write("Informe a operação desejada: ");

                // Lê a opção do usuário
                while (!int.TryParse(Console.ReadLine(), out opcao) || opcao < 1 || opcao > 5)
                {
                    Console.Write("Opção inválida! Informe novamente: ");
                }

                switch (opcao)
                {
                    case 1:
                        AdicionarConvenio();
                        break;
                    case 2:
                        RemoverConvenio();
                        break;
                    case 3:
                        ListarConvenios();
                        break;
                    case 4:
                        SalvarConvenios();
                        break;
                    case 5:
                        Console.WriteLine("Saindo...");
                        break;
                }

            } while (opcao != 5);
        }

        private static void AdicionarConvenio()
        {
            Console.Write("Informe o CNPJ: ");
            string cnpj = Console.ReadLine();
            Console.Write("Informe a razão social: ");
            string razaoSocial = Console.ReadLine();
            Console.Write("Informe a quantidade de empregados: ");
            int quantidadeEmpregados = int.Parse(Console.ReadLine());
            Console.Write("Informe o status (1-Cadastro, 2-Deferido, 3-Suspenso): ");
            StatusConvenio status = (StatusConvenio)int.Parse(Console.ReadLine());
            Console.Write("Informe a data de atualização (dd/MM/yyyy): ");
            DateTime dataAtualizacao = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);

            var retorno = cadastro.CadastrarConvenio(cnpj, razaoSocial, quantidadeEmpregados, status, dataAtualizacao);
            Console.WriteLine(retorno.Mensagem);
        }

        private static void RemoverConvenio()
        {
            Console.Write("Informe o CNPJ do convênio a ser removido: ");
            string cnpj = Console.ReadLine();
            var retorno = cadastro.RemoverConvenio(cnpj);
            Console.WriteLine(retorno.Mensagem);
        }

        private static void ListarConvenios()
        {
            var retorno = cadastro.ListarConvenios();
            Console.WriteLine(retorno.Mensagem);
            if (retorno.Codigo == 0 && retorno.Dados is List<Convenio> lista)
            {
                foreach (var conv in lista)
                {
                    Console.WriteLine($"CNPJ: {conv.CNPJ}, Razão Social: {conv.RazaoSocial}, Qtd Empregados: {conv.QtdEmpregados}, Status: {conv.Status}, Data Atualização: {conv.DtAtuStatus:dd/MM/yyyy}");
                }
            }
        }

        private static void SalvarConvenios()
        {
            var retorno = cadastro.SalvarConvênios();
            Console.WriteLine(retorno.Mensagem);
        }
    }
}

