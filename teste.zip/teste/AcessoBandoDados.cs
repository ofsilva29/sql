﻿using System;
using System.Data;
using System.Data.OleDb;

namespace teste
{
    public class AcessoBancoDados : IDisposable
    {
        private readonly string connectionString;
        private OleDbConnection connection;

        public AcessoBancoDados(string path)
        {
            if (!System.IO.File.Exists(path))
            {
                throw new FileNotFoundException($"O arquivo '{path}' não foi encontrado.");
            }

            connectionString = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path};Persist Security Info=False;";
        }

        public void Abrir()
        {
            if (connection == null)
            {
                connection = new OleDbConnection(connectionString);
            }
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        public void Fechar()
        {
            if (connection != null && connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        public bool ExecutarInsert(string comandoSQL)
        {
            using (var command = new OleDbCommand(comandoSQL, connection))
            {
                try
                {
                    command.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao executar o comando: {ex.Message}");
                    return false;
                }
            }
        }

        public void Dispose()
        {
            Fechar();
        }
    }
}

